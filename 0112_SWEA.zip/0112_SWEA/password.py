a, b = map(int,input().split())

result = a - b + 1
print(result)